#include "mylist.h"


///inicializuje liste
ListElem*  InitList(Particle* particle_pt){
    ListElem *New= new ListElem;
    New->particle_pt=particle_pt; 
    New->next=NULL; //ustawiam wsk na NULL

return New;
}


///dodaje do listy nowy element
void AddToList(ListElem *prev_elem, Particle* particle_pt){
    ListElem *New = FindLastElem(prev_elem);//przypisuje ostatni element do wskaznika
    ListElem *New_next = new ListElem;
    
    ///dodaje nowy element
    New->next = New_next;
    New_next->particle_pt = particle_pt;
    New_next->next = NULL;
}



///szuka ostatni element
ListElem *FindLastElem(ListElem *init_elem){
    ListElem *New=init_elem;
    ///szukam element ktory wskazuje na NULL, to znaczy ze jest ostatni
    while(New->next!=NULL){
        New=New->next;
    }
    New->next=NULL;
    return New;
}



///usuwa liste
void RemoveList(ListElem *init_elem){
    
    if(init_elem->next == NULL){
        delete init_elem;
    }
    else{
        ///za pomoca rekurencji 
        RemoveList(init_elem->next);
            delete init_elem; 
    }
}