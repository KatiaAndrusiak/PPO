#include "particle.h"


void SetParticle(Particle &particle, const char* name, double mass){
    particle.name= name;
    particle.mass= mass;
}