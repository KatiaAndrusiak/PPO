#ifndef fvectaux_h
#define fvectaux_h
#include "fvector.h"

void RemoveAllFourVectors(FourVector **fvectors,int rozm);
#endif