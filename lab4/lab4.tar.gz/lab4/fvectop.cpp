#include<cmath>
#include "fvector.h"

///Funkcja ktora oblicza mase niezmiennicza
double InvariantMass(double *vect){
    double masa;
    masa=sqrt(vect[0] * vect[0] - vect[1] * vect[1] - vect[2] * vect[2] - vect[3] * vect[3]);
    return masa;
}
///Funkcja ktora dodaje vectory
FourVector AddFourVectors(FourVector vect1, FourVector vect2){
    FourVector vect_s;
    vect_s.x=vect1.x + vect2.x;
    vect_s.y=vect1.y + vect2.y;
    vect_s.z=vect1.z + vect2.z;
    vect_s.t=vect1.t + vect2.t;
return vect_s;
}

///Funkcja ktora oblica scalar
double ScalarProduct(FourVector vect1, FourVector vect2){
    double scalar=0.0;
    scalar=sqrt(vect1.x * vect2.x + vect1.y *vect1.y + vect1.z * vect2.z + vect1.t * vect2.t);
    return scalar;
}

