
#include <iostream>
#include "library.h"
#include "book.h"
using namespace std;



Book** Library::get_books(){
    return lib;
}
Book* Library::get_book(string t){
    for(int i=0;i<akt;i++){
        if(t==lib[i]->get_author()) return lib[i];
    }
    cout<<"Looking for book: "<<t<<" ...   not found."<<endl;
}
void Library::new_book(Book tmp){
    if(akt+1>poj) cout<<"not space"<<endl;
    else{
        lib[akt]=new Book(tmp);
        akt++;
    }
}
int Library::get_n_books(){
    return akt;
}