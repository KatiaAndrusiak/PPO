#include "coin.h"
#include "piggybank.h"

Piggybank::Piggybank(int rozm){
        size=rozm;
        tab=new int [rozm];
        ix=0;
        
    }

void Piggybank::put_coin(Coin &pln){
    tab[ix]=pln.get_coin_value();
    ix++;
}

int Piggybank::get_tot_value(){
    int sum;
    int i;
    for(i=0; i<ix; i++ ){
        sum+=tab[i];
    }
    return sum;
}
