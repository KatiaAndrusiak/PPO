#ifndef piggybank_h
#define piggybank_h

class Piggybank{
public:
    Piggybank(int rozm);
    void put_coin(Coin &pln);
    int get_tot_value();
private:
    int size;
    int *tab;
    int ix;
   
};


#endif