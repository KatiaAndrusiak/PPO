#include "coin.h"
#include <iostream>

Coin::Coin(coin cop){
    value=cop;
}


Coin::Coin(){
    
    value=get_coin_value();
}


 coin Coin::get_coin_value(){
    return value;
}

void Coin::print_side_up(){
    if(Side==0) {
    std::cout<<"heads"<<std::endl;
    }
    else
        std::cout<<"tails"<<std::endl;
}

int Coin::toss(){
    Side=rand()%1;
  return Side;
}
    